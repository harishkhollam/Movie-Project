from django.conf.urls import url
from django.contrib import admin


from module1.views import(
	module1_list,
)


urlpatterns = [
    url(r'^$',module1_list,name='module1'),    
]
