import json
from django.http import Http404, HttpResponse
from django.shortcuts import render,get_object_or_404
from .models import Post,Comments
from django.http import HttpResponseRedirect
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.views.decorators.csrf import csrf_protect

def more_todo(request):
    if request.is_ajax():
    	print(request.POST.get('item'))
    	data1 = request.POST.get('item')
    	queryset = Post.objects.filter(title__contains=data1)
    	context = {
            "object_list":queryset,
            "title":"List"
            }
        return HttpResponse(json.dumps(context), content_type='application/json')
    else:
        raise Http404

def add_todo(request):
    if request.is_ajax() and request.POST:
        data = {'message': "%s added" % request.POST.get('item')}
        return HttpResponse(json.dumps(data), content_type='application/json')
    else:
        raise Http404