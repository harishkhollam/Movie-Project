from django.contrib import admin

# Register your models here.

from .models import Post,Comments

class PostModelAdmin1(admin.ModelAdmin): 
    list_display = ["title","update","timestamp"]
    list_filter = ["update"]
    search_fields = ["title","content"]
    class Meta:
        model = Post
        
class PostModelAdmin2(admin.ModelAdmin): 
    list_display = ["movie_id","comment"]
    list_filter = ["movie_id"]
    search_fields = ["movie_id","comment"]
    class Meta:
        model = Post

admin.site.register(Post,PostModelAdmin1)
admin.site.register(Comments,PostModelAdmin2)