from django.http import HttpResponse
from django.shortcuts import render,get_object_or_404

from .models import Post,Comments
#from .forms import PostForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.views.decorators.csrf import csrf_protect
from django.shortcuts import render_to_response
from django.http import HttpResponseRedirect
from django.template import RequestContext

##try for search

# Create your views here. 
def posts_create(request):
    return HttpResponse("<h1>Create</h1>")

def posts_detail(request,id):
    queryset = Post.objects.get(id=id)
    queryset2 = Comments.objects.filter(movie_id=id)
    #instance = get_object_or_404(Post,id=id)
    #comment = get_object_or_404(Comments,movie_id=id)
    context = {
        "title":"Detail",
        "instance":queryset,
        "comment":queryset2
     }
    return render(request,"post_detail.html",context)

def posts_list(request):
    queryset = Post.objects.all()
#    if request.user.is_authenticated():
#    context = {
#            "title":"My User"    
#            }
#    else:
    context = {
            "object_list":queryset,
            "title":"List"
            }
    return render(request,"index.html",context)
    #return HttpResponse("<h1>List</h1>")

def posts_update(request):
    return HttpResponse("<h1>Update</h1>")

def posts_delete(request):
    return HttpResponse("<h1>Delete</h1>")

def posts_array(request):
    return render(request,"array1.php",context)
    


#login content







