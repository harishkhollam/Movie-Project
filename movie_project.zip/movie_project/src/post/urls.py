# -*- coding: utf-8 -*-
from django.conf.urls import url
from django.contrib import admin


from .views import(
    posts_list,
    posts_create,
    posts_detail,
    posts_update,
    posts_delete,
    posts_array,
)

from module1.views import(
	module1_list,
)


urlpatterns = [

    url(r'^$',posts_list),
    url(r'^create/$',posts_create),
   	url(r'^ajax/more/$','post.ajax.more_todo'),
    url(r'^(?P<id>\d+)/$',posts_detail, name ='detail'),
    url(r'^update/$',posts_update),
    url(r'module1/$',module1_list,name='module1'),
    url(r'^delete/$',posts_delete),
    url(r'^array1/$',posts_array),
    
]

