$(document).ready(function() {

    // AJAX GET
    $('.abcd').click(function(){

        $.ajax({
            type:"POST",
            dataType: 'json',
            data: { "item": $("#search").val()},
            url: "http://127.0.0.1:8000/home/ajax/more/",
            success: function(data) {
             $('.row').append(data.object_list)
            alert(data.object_list);
            alert(data.title);
           	//for(i = 0; i < data.length; i++){
           	
           	//$('.row').append('<li>'+this.object_list+'</li>');
            //    $(".row").append('<div class="col-md-5">');
            //    $(".col-md-5").append(data[i]);
            //    $("<div id=" + j + " class="+classname+"></div>").hide().appendTo("#popup_box_friend").fadeIn();
			//  $("<div id=" + i + " class="+subclass+"></div>").hide().appendTo("."+classname+"").fadeIn();
                //<h3><a href='{{object.get_absolute_url}}'>{{object.title}}</a></h3>
                //<h4>Movie no :{{object.id}}</h4>
                //<p>{{object.content}}</p>
                //<a class="btn btn-primary" href='{{object.get_absolute_url}}' {{object.title}}>View Movie Details<span class="glyphicon glyphicon-chevron-right"></span></a>
           // </div>
            //}
        }
        });

    });


    // AJAX POST
    $('.add-todo').click(function(){
      console.log('am i called');

        $.ajax({
            type: "POST",
            url: "/ajax/add/",
            dataType: "json",
            data: { "item": $(".todo-item").val() },
            success: function(data) {
                alert(data.message);
            }
        });

    });



    // CSRF code
    function getCookie(name) {
        var cookieValue = null;
        var i = 0;
        if (document.cookie && document.cookie !== '') {
            var cookies = document.cookie.split(';');
            for (i; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    var csrftoken = getCookie('csrftoken');

    function csrfSafeMethod(method) {
        // these HTTP methods do not require CSRF protection
        return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
    }
    $.ajaxSetup({
        crossDomain: false, // obviates need for sameOrigin test
        beforeSend: function(xhr, settings) {
            if (!csrfSafeMethod(settings.type)) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
            }
        }
    }); 


});